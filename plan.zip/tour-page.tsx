// app/tury/[slug]/page.tsx
// Серверный компонент страницы тура («пост» + CTA).
// Решает 3 задачи сразу: индексация (SSG/ISR), доверие (богатый контент), конверсия (кнопки).

import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import {
  tourProductJsonLd,
  touristTripJsonLd,
  faqJsonLd,
  breadcrumbJsonLd,
  jsonLdScript,
  type TourForSeo,
  type FaqItem,
} from '@/lib/seo/jsonld';
import TourBookingBar from '@/components/tour/TourBookingBar';
import TourFaq from '@/components/tour/TourFaq';
import TourGuideCard from '@/components/tour/TourGuideCard';
import { getTourBySlug } from '@/lib/tours'; // TODO: ваш слой данных

// --- ISR: страница статична, перегенерируется раз в час (или вебхуком из админки) ---
export const revalidate = 3600;

// Заранее сгенерировать самые ходовые туры на билде (опционально):
// export async function generateStaticParams() {
//   const slugs = await getTopTourSlugs();
//   return slugs.map((slug) => ({ slug }));
// }

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://energy-tur.ru';

type PageProps = { params: Promise<{ slug: string }> };

// --- МЕТАДАННЫЕ: уникальные title/description/OG на каждый тур ---
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const tour = await getTourBySlug(slug);
  if (!tour) return {};

  const title = `«${tour.title}» — авторский тур с гидом${
    tour.durationDays ? ` · ${tour.durationDays} дн.` : ''
  } · от ${tour.price.toLocaleString('ru-RU')} ₽`;
  const description =
    tour.metaDescription ??
    `${tour.shortDescription} Бронируйте онлайн или задайте вопрос гиду напрямую.`;
  const url = `${BASE_URL}/tury/${tour.slug}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title,
      description,
      url,
      type: 'article',
      images: tour.images.map((src) => ({ url: src })),
      locale: 'ru_RU',
      siteName: 'energy-tur',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: tour.images.slice(0, 1),
    },
  };
}

export default async function TourPage({ params }: PageProps) {
  const { slug } = await params;
  const tour = await getTourBySlug(slug);
  if (!tour) notFound();

  // Данные для разметки
  const seoTour: TourForSeo = {
    slug: tour.slug,
    title: tour.title,
    description: tour.shortDescription,
    images: tour.images,
    price: tour.price,
    durationDays: tour.durationDays,
    rating: tour.rating,
    guide: tour.guide ? { name: tour.guide.name, slug: tour.guide.slug } : null,
    region: tour.region,
  };
  const faqItems: FaqItem[] = tour.faq ?? [];

  return (
    <article className="mx-auto max-w-3xl px-4 pb-28">
      {/* ---- JSON-LD разметка (невидимая, для поисковиков) ---- */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={jsonLdScript(tourProductJsonLd(seoTour))}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={jsonLdScript(touristTripJsonLd(seoTour))}
      />
      {faqItems.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={jsonLdScript(faqJsonLd(faqItems))}
        />
      )}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={jsonLdScript(
          breadcrumbJsonLd([
            { name: 'Главная', path: '/' },
            { name: 'Туры', path: '/tury' },
            { name: tour.title, path: `/tury/${tour.slug}` },
          ])
        )}
      />

      {/* ---- HERO: главное фото + ключевые факты сразу ---- */}
      <header className="pt-6">
        <h1 className="text-3xl font-bold tracking-tight">{tour.title}</h1>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-600">
          {tour.durationDays && <span>{tour.durationDays} дней</span>}
          {tour.region && <span>{tour.region}</span>}
          {tour.groupSize && <span>группа до {tour.groupSize}</span>}
          {tour.rating && tour.rating.count > 0 && (
            <span>★ {tour.rating.value} ({tour.rating.count} отзывов)</span>
          )}
          <span className="font-semibold text-gray-900">
            от {tour.price.toLocaleString('ru-RU')} ₽
          </span>
        </div>

        {tour.images[0] && (
          <div className="relative mt-4 aspect-[16/9] overflow-hidden rounded-xl">
            <Image
              src={tour.images[0]}
              alt={`Тур «${tour.title}»`}
              fill
              priority /* главное фото грузим в приоритете -> хороший LCP */
              sizes="(max-width: 768px) 100vw, 768px"
              className="object-cover"
            />
          </div>
        )}
      </header>

      {/* ---- ОПИСАНИЕ-ИСТОРИЯ (рендерим из БД как HTML/MDX) ---- */}
      <section className="prose prose-neutral mt-8 max-w-none">
        {/* TODO: если контент хранится как HTML из админки — санитизируйте перед вставкой */}
        <div dangerouslySetInnerHTML={{ __html: tour.bodyHtml }} />
      </section>

      {/* ---- ПРОГРАММА ПО ДНЯМ ---- */}
      {tour.itinerary?.length > 0 && (
        <section className="mt-10">
          <h2 className="text-2xl font-semibold">Программа</h2>
          <ol className="mt-4 space-y-4">
            {tour.itinerary.map((day, i) => (
              <li key={i} className="border-l-2 border-gray-200 pl-4">
                <h3 className="font-medium">
                  День {i + 1}. {day.title}
                </h3>
                <p className="mt-1 text-gray-700">{day.description}</p>
              </li>
            ))}
          </ol>
        </section>
      )}

      {/* ---- ЧТО ВКЛЮЧЕНО / ВЗЯТЬ С СОБОЙ ---- */}
      {(tour.included?.length || tour.bring?.length) && (
        <section className="mt-10 grid gap-6 sm:grid-cols-2">
          {tour.included?.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold">Что включено</h2>
              <ul className="mt-3 list-disc space-y-1 pl-5 text-gray-700">
                {tour.included.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
          )}
          {tour.bring?.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold">Что взять с собой</h2>
              <ul className="mt-3 list-disc space-y-1 pl-5 text-gray-700">
                {tour.bring.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}

      {/* ---- ГИД-АВТОР (доверие + перелинковка) ---- */}
      {tour.guide && (
        <section className="mt-10">
          <h2 className="text-2xl font-semibold">Ваш гид</h2>
          <div className="mt-4">
            <TourGuideCard guide={tour.guide} />
          </div>
        </section>
      )}

      {/* ---- ОТЗЫВЫ (соцдоказательство + звёзды в выдаче) ---- */}
      {/* TODO: компонент отзывов <TourReviews tourId={tour.id} /> */}

      {/* ---- FAQ (кормит FAQPage-разметку) ---- */}
      {faqItems.length > 0 && (
        <section className="mt-10">
          <h2 className="text-2xl font-semibold">Частые вопросы</h2>
          <TourFaq items={faqItems} />
        </section>
      )}

      {/* ---- ЛИПКАЯ ПАНЕЛЬ CTA (всегда под рукой на мобильных) ---- */}
      <TourBookingBar
        tourId={tour.id}
        tourTitle={tour.title}
        guideId={tour.guide?.id ?? null}
        price={tour.price}
      />
    </article>
  );
}
