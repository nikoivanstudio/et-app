// app/api/conversations/[id]/messages/route.ts
// GET  — получить сообщения треда (опц. ?after=<messageId> для дозагрузки новых)
// POST — отправить сообщение в тред
import { NextResponse } from 'next/server';
import { getMessages, addMessage, assertParticipant, markRead } from '@/lib/messages';
import { notifyGuideNewQuestion } from '@/lib/telegram';
import { query } from '@/lib/db';
// import { getSession } from '@/lib/auth';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: Request, { params }: Ctx) {
  const { id } = await params;
  // const session = await getSession();
  const session: { userId: string } | null = null; // TODO
  if (!session) return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });

  if (!(await assertParticipant(id, session.userId))) {
    return NextResponse.json({ error: 'Нет доступа' }, { status: 403 });
  }

  const after = new URL(req.url).searchParams.get('after') ?? undefined;
  const messages = await getMessages(id, after);
  await markRead(id, session.userId);
  return NextResponse.json({ messages });
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  // const session = await getSession();
  const session: { userId: string; name: string } | null = null; // TODO
  if (!session) return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });

  if (!(await assertParticipant(id, session.userId))) {
    return NextResponse.json({ error: 'Нет доступа' }, { status: 403 });
  }

  const { body } = await req.json();
  const text = (body ?? '').trim();
  if (text.length < 1 || text.length > 2000) {
    return NextResponse.json({ error: 'Пустое или слишком длинное сообщение' }, { status: 400 });
  }

  const message = await addMessage({ conversationId: id, senderId: session.userId, body: text });

  // Уведомить вторую сторону (если получатель — гид) в Telegram.
  const { rows } = await query<{
    guide_id: string;
    client_id: string;
    title: string | null;
    guide_chat: string | null;
  }>(
    `select c.guide_id, c.client_id, t.title, u.telegram_chat_id as guide_chat
       from conversations c
       left join tours t on t.id = c.tour_id
       left join users u on u.id = c.guide_id
      where c.id = $1`,
    [id]
  );
  const conv = rows[0];
  if (conv && conv.client_id === session.userId) {
    // писал клиент -> уведомляем гида
    await notifyGuideNewQuestion({
      guideChatId: conv.guide_chat,
      tourTitle: conv.title ?? 'Тур',
      questionBody: text,
      fromName: session.name,
      conversationId: id,
    });
  }
  // TODO: если писал гид -> уведомить клиента (email/пуш).

  return NextResponse.json({ message });
}
