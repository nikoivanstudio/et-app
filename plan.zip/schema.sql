-- messaging/schema.sql
-- Накатить как миграцию. Источник правды для модели сообщений (любой ORM).
-- Предполагается, что таблицы users и tours уже есть.

-- gen_random_uuid() доступен в Postgres 13+ (расширение pgcrypto в более старых).
create extension if not exists pgcrypto;

-- 1) Гиду нужно поле для Telegram-уведомлений.
alter table users add column if not exists telegram_chat_id text;

-- =========================================================================
-- ЛИДЫ: быстрый вопрос с карточки тура. Работает для ГОСТЕЙ (без регистрации).
-- Цель — максимум заявок. Гиду сразу падает уведомление в Telegram.
-- =========================================================================
create table if not exists tour_questions (
  id          uuid primary key default gen_random_uuid(),
  tour_id     uuid references tours(id) on delete set null,
  guide_id    uuid references users(id) on delete set null,
  -- если задал залогиненный пользователь:
  user_id     uuid references users(id) on delete set null,
  -- если задал гость:
  guest_name    text,
  guest_contact text,            -- телефон / telegram / email
  body        text not null,
  status      text not null default 'new',   -- new | answered | spam
  source      text,                          -- 'tour_page' и т.п. (для аналитики)
  created_at  timestamptz not null default now(),
  -- должен быть хоть какой-то способ ответить:
  constraint contact_present check (user_id is not null or guest_contact is not null)
);

create index if not exists idx_tour_questions_guide on tour_questions (guide_id, status);
create index if not exists idx_tour_questions_tour  on tour_questions (tour_id);

-- =========================================================================
-- ПЕРЕПИСКА: полноценный тред для ЗАЛОГИНЕННЫХ пользователей.
-- Один тред на пару (тур + клиент + гид).
-- =========================================================================
create table if not exists conversations (
  id          uuid primary key default gen_random_uuid(),
  tour_id     uuid references tours(id) on delete set null,  -- null = общий вопрос гиду
  client_id   uuid not null references users(id) on delete cascade,
  guide_id    uuid not null references users(id) on delete cascade,
  status      text not null default 'open',   -- open | closed
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (tour_id, client_id, guide_id)
);

create index if not exists idx_conv_guide  on conversations (guide_id, status, updated_at desc);
create index if not exists idx_conv_client on conversations (client_id, status, updated_at desc);

create table if not exists messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id       uuid not null references users(id) on delete cascade,
  body            text not null,
  created_at      timestamptz not null default now(),
  read_at         timestamptz
);

create index if not exists idx_messages_conv on messages (conversation_id, created_at);
-- для подсчёта непрочитанных:
create index if not exists idx_messages_unread on messages (conversation_id) where read_at is null;
