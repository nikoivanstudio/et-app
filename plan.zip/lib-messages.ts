// lib/messages.ts
// Репозиторий обращений к гиду: лиды-вопросы (гости) и переписка (залогиненные).
import { query } from '@/lib/db';

// ---------- ЛИДЫ (быстрый вопрос, в т.ч. от гостя) ----------

export type CreateQuestionInput = {
  tourId: string | null;
  guideId: string | null;
  userId: string | null;
  guestName?: string | null;
  guestContact?: string | null;
  body: string;
  source?: string;
};

export async function createTourQuestion(input: CreateQuestionInput) {
  const { rows } = await query<{ id: string }>(
    `insert into tour_questions
       (tour_id, guide_id, user_id, guest_name, guest_contact, body, source)
     values ($1,$2,$3,$4,$5,$6,$7)
     returning id`,
    [
      input.tourId,
      input.guideId,
      input.userId,
      input.guestName ?? null,
      input.guestContact ?? null,
      input.body,
      input.source ?? 'tour_page',
    ]
  );
  return rows[0].id;
}

// ---------- ПЕРЕПИСКА (для залогиненных) ----------

/** Находит существующий тред (тур+клиент+гид) или создаёт новый. */
export async function getOrCreateConversation(params: {
  tourId: string | null;
  clientId: string;
  guideId: string;
}) {
  const { rows } = await query<{ id: string }>(
    `insert into conversations (tour_id, client_id, guide_id)
     values ($1,$2,$3)
     on conflict (tour_id, client_id, guide_id)
     do update set updated_at = now()
     returning id`,
    [params.tourId, params.clientId, params.guideId]
  );
  return rows[0].id;
}

export async function addMessage(params: {
  conversationId: string;
  senderId: string;
  body: string;
}) {
  const { rows } = await query<{ id: string; created_at: Date }>(
    `insert into messages (conversation_id, sender_id, body)
     values ($1,$2,$3)
     returning id, created_at`,
    [params.conversationId, params.senderId, params.body]
  );
  await query(`update conversations set updated_at = now() where id = $1`, [
    params.conversationId,
  ]);
  return rows[0];
}

export type MessageRow = {
  id: string;
  sender_id: string;
  body: string;
  created_at: Date;
  read_at: Date | null;
};

/** Сообщения треда. Если передан afterId — только новые (для SSE/поллинга). */
export async function getMessages(conversationId: string, afterId?: string) {
  if (afterId) {
    const { rows } = await query<MessageRow>(
      `select id, sender_id, body, created_at, read_at
         from messages
        where conversation_id = $1
          and created_at > (select created_at from messages where id = $2)
        order by created_at`,
      [conversationId, afterId]
    );
    return rows;
  }
  const { rows } = await query<MessageRow>(
    `select id, sender_id, body, created_at, read_at
       from messages
      where conversation_id = $1
      order by created_at`,
    [conversationId]
  );
  return rows;
}

/** Проверка, что пользователь — участник треда (защита доступа). */
export async function assertParticipant(conversationId: string, userId: string) {
  const { rows } = await query<{ client_id: string; guide_id: string }>(
    `select client_id, guide_id from conversations where id = $1`,
    [conversationId]
  );
  const conv = rows[0];
  if (!conv) return false;
  return conv.client_id === userId || conv.guide_id === userId;
}

export async function markRead(conversationId: string, readerId: string) {
  // помечаем прочитанными чужие сообщения в треде
  await query(
    `update messages set read_at = now()
      where conversation_id = $1 and sender_id <> $2 and read_at is null`,
    [conversationId, readerId]
  );
}

/** Сводка непрочитанных для бейджа в шапке кабинета. */
export async function unreadCount(userId: string) {
  const { rows } = await query<{ count: string }>(
    `select count(*)::int as count
       from messages m
       join conversations c on c.id = m.conversation_id
      where (c.client_id = $1 or c.guide_id = $1)
        and m.sender_id <> $1
        and m.read_at is null`,
    [userId]
  );
  return Number(rows[0]?.count ?? 0);
}
