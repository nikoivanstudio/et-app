'use client';
// components/tour/AskQuestionModal.tsx
// Модалка «Задать вопрос». Без HTML <form> (управляемые поля + onClick).
// Для гостя показываем поля имени и контакта. Доступность: Esc, фокус, aria.

import { useEffect, useRef, useState } from 'react';

type Props = {
  open: boolean;
  onClose: () => void;
  tourId: string;
  tourTitle: string;
  guideId: string | null;
  isAuthenticated?: boolean; // TODO: пробросить из сессии
};

export default function AskQuestionModal({
  open,
  onClose,
  tourId,
  tourTitle,
  guideId,
  isAuthenticated = false,
}: Props) {
  const [body, setBody] = useState('');
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [error, setError] = useState('');
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    dialogRef.current?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  async function submit() {
    setError('');
    if (body.trim().length < 3) {
      setError('Напишите вопрос');
      return;
    }
    if (!isAuthenticated && !contact.trim()) {
      setError('Укажите контакт, чтобы гид мог ответить');
      return;
    }
    setState('sending');
    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tourId,
          guideId,
          body: body.trim(),
          guestName: name.trim() || undefined,
          guestContact: contact.trim() || undefined,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? 'Не удалось отправить');
      }
      window.ym?.(0, 'reachGoal', 'ask_question', { tourId });
      setState('done');
    } catch (e) {
      setState('error');
      setError(e instanceof Error ? e.message : 'Ошибка отправки');
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Вопрос по туру ${tourTitle}`}
    >
      <div
        ref={dialogRef}
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-2xl bg-white p-5 shadow-xl outline-none sm:rounded-2xl"
      >
        {state === 'done' ? (
          <div className="py-4 text-center">
            <p className="text-lg font-semibold">Вопрос отправлен</p>
            <p className="mt-1 text-sm text-gray-600">Гид ответит вам в ближайшее время.</p>
            <button
              onClick={onClose}
              className="mt-4 rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700"
            >
              Закрыть
            </button>
          </div>
        ) : (
          <>
            <h3 className="text-lg font-semibold">Вопрос гиду</h3>
            <p className="mt-0.5 text-sm text-gray-500">по туру «{tourTitle}»</p>

            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={4}
              maxLength={2000}
              placeholder="Что хотите уточнить?"
              className="mt-3 w-full resize-none rounded-lg border border-gray-300 p-3 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />

            {!isAuthenticated && (
              <div className="mt-3 space-y-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ваше имя"
                  className="w-full rounded-lg border border-gray-300 p-3 text-sm focus:border-emerald-500 focus:outline-none"
                />
                <input
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="Телефон, Telegram или e-mail"
                  className="w-full rounded-lg border border-gray-300 p-3 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
            )}

            {error && <p className="mt-2 text-sm text-red-600">{error}</p>}

            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={onClose}
                className="rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium hover:bg-gray-50"
              >
                Отмена
              </button>
              <button
                onClick={submit}
                disabled={state === 'sending'}
                className="rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
              >
                {state === 'sending' ? 'Отправляем…' : 'Отправить вопрос'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
