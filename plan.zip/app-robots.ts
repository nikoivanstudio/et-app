// app/robots.ts
// Next.js сам отдаёт это по адресу /robots.txt
import type { MetadataRoute } from 'next';

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://energy-tur.ru';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        // Закрываем от индексации всё, что не должно попадать в поиск:
        // личный кабинет, чаты, корзину, оформление, API, служебные параметры.
        disallow: [
          '/api/',
          '/cabinet/',
          '/account/',
          '/messages/',
          '/chat/',
          '/checkout/',
          '/cart/',
          '/*?*utm_', // ссылки с utm-метками — чтобы не плодить дубли
        ],
      },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
    host: BASE_URL,
  };
}
