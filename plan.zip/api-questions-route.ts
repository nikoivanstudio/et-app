// app/api/questions/route.ts
// POST: вопрос с карточки тура. Работает для гостей и для залогиненных.
// Гость -> лид в tour_questions + Telegram гиду.
// Залогиненный -> то же + открывается тред переписки.
import { NextResponse } from 'next/server';
import { createTourQuestion, getOrCreateConversation, addMessage } from '@/lib/messages';
import { notifyGuideNewQuestion } from '@/lib/telegram';
import { query } from '@/lib/db';
// import { getSession } from '@/lib/auth'; // TODO: ваша авторизация

// Примитивный рейт-лимит в памяти (на проде — Redis/Upstash).
const hits = new Map<string, { count: number; ts: number }>();
function rateLimited(ip: string, limit = 5, windowMs = 60_000) {
  const now = Date.now();
  const rec = hits.get(ip);
  if (!rec || now - rec.ts > windowMs) {
    hits.set(ip, { count: 1, ts: now });
    return false;
  }
  rec.count += 1;
  return rec.count > limit;
}

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] ?? 'unknown';
  if (rateLimited(ip)) {
    return NextResponse.json({ error: 'Слишком много запросов, попробуйте позже' }, { status: 429 });
  }

  let payload: {
    tourId: string;
    guideId: string | null;
    body: string;
    guestName?: string;
    guestContact?: string;
  };
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некорректный запрос' }, { status: 400 });
  }

  const body = (payload.body ?? '').trim();
  if (body.length < 3 || body.length > 2000) {
    return NextResponse.json({ error: 'Введите вопрос (до 2000 символов)' }, { status: 400 });
  }

  // const session = await getSession();
  const session: { userId: string; name: string } | null = null; // TODO: подставить
  const userId = session?.userId ?? null;

  // Гость обязан оставить контакт
  if (!userId && !payload.guestContact?.trim()) {
    return NextResponse.json({ error: 'Укажите контакт для ответа' }, { status: 400 });
  }

  // 1) Сохраняем лид (нужно всегда — это «продажная» сущность)
  await createTourQuestion({
    tourId: payload.tourId,
    guideId: payload.guideId,
    userId,
    guestName: payload.guestName,
    guestContact: payload.guestContact,
    body,
    source: 'tour_page',
  });

  // 2) Для залогиненного — заводим тред переписки
  let conversationId: string | null = null;
  if (userId && payload.guideId) {
    conversationId = await getOrCreateConversation({
      tourId: payload.tourId,
      clientId: userId,
      guideId: payload.guideId,
    });
    await addMessage({ conversationId, senderId: userId, body });
  }

  // 3) Уведомляем гида в Telegram
  const { rows } = await query<{ title: string; telegram_chat_id: string | null }>(
    `select t.title, u.telegram_chat_id
       from tours t
       left join users u on u.id = $2
      where t.id = $1`,
    [payload.tourId, payload.guideId]
  );
  const tour = rows[0];
  await notifyGuideNewQuestion({
    guideChatId: tour?.telegram_chat_id ?? null,
    tourTitle: tour?.title ?? 'Тур',
    questionBody: body,
    fromName: session?.name ?? payload.guestName ?? 'Гость',
    contact: payload.guestContact,
    conversationId,
  });

  return NextResponse.json({ ok: true, conversationId });
}
