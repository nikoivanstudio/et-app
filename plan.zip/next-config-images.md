# next.config.js — изображения из Minio

Главная угроза скорости (а значит, и SEO) на турсайте — тяжёлые фото из Minio.
`next/image` решает это: отдаёт WebP/AVIF нужного размера. Нужно разрешить домен Minio.

```js
// next.config.js  (или next.config.mjs)
const nextConfig = {
  images: {
    // Разрешаем оптимизатору Next тянуть картинки с Minio.
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'minio.energy-tur.ru', // TODO: ваш публичный хост Minio
        // pathname: '/tours/**',         // можно сузить до бакета
      },
    ],
    formats: ['image/avif', 'image/webp'],
    // Под реальные брейкпоинты сайта:
    deviceSizes: [360, 640, 768, 1024, 1280, 1920],
  },
};

module.exports = nextConfig;
```

## Заметки

- **Главное фото тура** рендерим с `priority` (см. tour-page.tsx) — улучшает LCP.
- **Галерею** — ленивой загрузкой (по умолчанию у `next/image`).
- **alt у всех картинок** заполняем осмысленно: и доступность, и картиночный трафик
  из Яндекс/Google Картинок.
- **Кеш перед Minio.** Оптимизатор Next кеширует результат, но первый запрос идёт в Minio.
  При большом трафике поставьте CDN/обратный прокси (nginx, Cloudflare) перед Minio,
  чтобы не дёргать хранилище на каждый запрос.
- **Если оптимизатор Next перегружает сервер** — можно вынести оптимизацию на CDN
  и использовать `unoptimized` точечно, но это крайний случай.

## Глобальная разметка организации

В `app/layout.tsx` добавьте организацию один раз на весь сайт:

```tsx
import { organizationJsonLd, jsonLdScript } from '@/lib/seo/jsonld';

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={jsonLdScript(organizationJsonLd())}
        />
        {children}
      </body>
    </html>
  );
}
```
