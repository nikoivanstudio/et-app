// app/api/conversations/[id]/stream/route.ts
// SSE (Server-Sent Events) — «почти real-time» без WebSocket-сервера.
// Клиент подписывается через EventSource, сервер отдаёт новые сообщения.
//
// ВАЖНО про деплой: длительные соединения держит обычный Node-сервер (next start, своя VM).
// В serverless (Vercel functions) долгоживущий SSE ограничен таймаутом — там лучше поллинг
// (GET ?after=... раз в 2-3 сек). У вас self-hosted Node — SSE подходит.
import { getMessages, assertParticipant } from '@/lib/messages';
// import { getSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: Request, { params }: Ctx) {
  const { id } = await params;
  // const session = await getSession();
  const session: { userId: string } | null = null; // TODO
  if (!session || !(await assertParticipant(id, session.userId))) {
    return new Response('Forbidden', { status: 403 });
  }

  const encoder = new TextEncoder();
  let lastId: string | undefined;
  let closed = false;

  const stream = new ReadableStream({
    async start(controller) {
      const send = (event: string, data: unknown) =>
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));

      // Отдаём всю историю при подключении
      const initial = await getMessages(id);
      lastId = initial.at(-1)?.id;
      send('init', initial);

      // Пуллим новые сообщения и пушим клиенту (простая и надёжная схема).
      const poll = setInterval(async () => {
        if (closed) return;
        try {
          const fresh = await getMessages(id, lastId);
          if (fresh.length) {
            lastId = fresh.at(-1)!.id;
            send('message', fresh);
          }
          // ping, чтобы прокси не рвал соединение
          controller.enqueue(encoder.encode(': ping\n\n'));
        } catch {
          /* проглатываем, попробуем на следующем тике */
        }
      }, 2500);

      // Закрытие соединения клиентом
      req.signal.addEventListener('abort', () => {
        closed = true;
        clearInterval(poll);
        try {
          controller.close();
        } catch {}
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  });
}

// Замечание: внутренний поллинг БД здесь скрыт от клиента и легко заменяется на
// Postgres LISTEN/NOTIFY, когда дойдут руки до настоящего real-time без интервала.
