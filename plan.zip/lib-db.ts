// lib/db.ts
// Тонкая обёртка над node-postgres. Если у вас уже есть db-слой (Prisma/Drizzle) — используйте его,
// а этот файл служит образцом сигнатур, которые ждут репозитории.
import { Pool, type QueryResultRow } from 'pg';

declare global {
  // eslint-disable-next-line no-var
  var _pgPool: Pool | undefined;
}

// Один пул на процесс (в dev переживает hot-reload через globalThis).
export const pool =
  global._pgPool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
  });

if (process.env.NODE_ENV !== 'production') global._pgPool = pool;

export async function query<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params?: unknown[]
) {
  return pool.query<T>(text, params);
}
