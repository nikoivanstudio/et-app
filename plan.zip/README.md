# energy-tur — технические скелеты

Пакет рабочих заготовок под Next.js (App Router) для трёх задач:
SEO, страница тура как «пост» с CTA, и сообщения/вопросы гиду.
Файлы — скелеты: структура и логика готовы, точки интеграции помечены `// TODO:`.

## Допущения (поправьте под себя)

- **Next.js 14+ App Router + TypeScript.** Если у вас Pages Router — `sitemap.ts`/`robots.ts`
  и `generateMetadata` работают иначе, скажите, дам версии под Pages Router.
- **Стили — Tailwind.** Если Tailwind нет — замените классы на свои, разметка не изменится.
- **БД — Postgres через `pg` (node-postgres).** Если у вас Prisma/Drizzle — DDL из
  `messaging/schema.sql` остаётся источником правды, репозиторий перепишется 1-в-1.
- **Авторизация** уже есть (NextAuth или своя). Везде, где нужен текущий пользователь,
  стоит `// TODO: getSession()`.
- **Таблицы `tours`, `users` уже существуют.** Я обращаюсь к полям
  `tours.id, slug, title, description, price, ...` и `users.id, name, role, telegram_chat_id`.
  Имена полей поправьте под свою схему.
- **Картинки лежат в Minio**, отдаются по публичному URL (см. `seo/next-config-images.md`).

## Структура

```
seo/
  app-robots.ts            -> app/robots.ts
  app-sitemap.ts           -> app/sitemap.ts
  lib-seo-jsonld.ts        -> lib/seo/jsonld.ts     (сборка JSON-LD)
  tour-page.tsx            -> app/tury/[slug]/page.tsx (server component + metadata + JSON-LD)
  next-config-images.md    -> правки next.config.js под Minio + изображения

tour-page/
  TourBookingBar.tsx       -> липкая панель CTA «Забронировать / Задать вопрос»
  TourFaq.tsx              -> аккордеон FAQ (кормит FAQPage-разметку)
  TourGuideCard.tsx        -> карточка гида-автора

messaging/
  schema.sql               -> DDL: conversations, messages, tour_questions
  lib-db.ts                -> lib/db.ts (пул соединений pg)
  lib-messages.ts          -> lib/messages.ts (репозиторий)
  lib-telegram.ts          -> lib/telegram.ts (уведомление гида)
  api-questions-route.ts   -> app/api/questions/route.ts (вопрос с карточки тура; работает для гостей)
  api-messages-route.ts    -> app/api/conversations/[id]/messages/route.ts (чат залогиненных)
  api-messages-stream-route.ts -> app/api/conversations/[id]/stream/route.ts (SSE, почти real-time)
  AskQuestionModal.tsx     -> клиентская модалка «Задать вопрос»

analytics/
  metrika.tsx              -> Яндекс.Метрика + хелпер целей (reachGoal)
```

## Порядок подключения

1. `messaging/schema.sql` — накатить миграцию (добавляет 3 таблицы + поле `telegram_chat_id` в users).
2. `seo/*` — самые быстрые победы по трафику, фич не требуют.
3. `tour-page/*` + интеграция в `tour-page.tsx` — страница-«пост» + кнопки.
4. `messaging/*` — вопросы/чат с уведомлением в Telegram.
5. `analytics/metrika.tsx` — цели, чтобы измерять эффект.

## Две модели обращений к гиду (важно)

- **Гость или быстрый вопрос** → таблица `tour_questions` (лид: имя, контакт, текст, тур) +
  моментальное уведомление гиду в Telegram. Не требует регистрации → максимум заявок.
- **Залогиненный пользователь** → полноценный тред `conversations` + `messages`
  (история, ответы в кабинете, SSE для живого обновления).

Кнопка «Задать вопрос» работает для всех. Если пользователь авторизован — дополнительно
открывается тред переписки.
