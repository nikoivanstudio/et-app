// lib/telegram.ts
// Уведомление гида в Telegram — ключ к скорости ответа, а значит к продажам.
// Гид жмёт /start у бота -> вы сохраняете chat_id в users.telegram_chat_id (см. ниже).

const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://energy-tur.ru';

async function sendTelegram(chatId: string, text: string, replyUrl?: string) {
  if (!TG_TOKEN) {
    console.warn('TELEGRAM_BOT_TOKEN не задан — уведомление пропущено');
    return;
  }
  const body: Record<string, unknown> = {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    disable_web_page_preview: true,
  };
  if (replyUrl) {
    body.reply_markup = {
      inline_keyboard: [[{ text: 'Ответить', url: replyUrl }]],
    };
  }
  try {
    await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch (e) {
    console.error('Telegram send error', e);
  }
}

/** Уведомление о новом вопросе с карточки тура. */
export async function notifyGuideNewQuestion(params: {
  guideChatId: string | null;
  tourTitle: string;
  questionBody: string;
  fromName: string;
  contact?: string | null;
  conversationId?: string | null;
}) {
  if (!params.guideChatId) return;
  const lines = [
    `🧭 <b>Новый вопрос по туру</b>`,
    `Тур: <b>${escapeHtml(params.tourTitle)}</b>`,
    `От: ${escapeHtml(params.fromName)}`,
    params.contact ? `Контакт: ${escapeHtml(params.contact)}` : '',
    ``,
    escapeHtml(params.questionBody),
  ]
    .filter(Boolean)
    .join('\n');

  const replyUrl = params.conversationId
    ? `${SITE}/cabinet/messages/${params.conversationId}`
    : `${SITE}/cabinet/questions`;

  await sendTelegram(params.guideChatId, lines, replyUrl);
}

function escapeHtml(s: string) {
  return s.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]!));
}

// --- Как привязать chat_id гида ---
// Вариант 1 (просто): бот с deep-link. Гид открывает t.me/your_bot?start=<userId>,
//   жмёт Start -> вебхук бота получает /start <userId> -> сохраняете
//   update.message.chat.id в users.telegram_chat_id для этого userId.
// Вариант 2: код-привязка в кабинете гида.
