// components/tour/TourGuideCard.tsx
// Карточка гида: фото, имя, опыт, рейтинг, ссылка на другие туры -> доверие + внутренняя перелинковка.

import Image from 'next/image';
import Link from 'next/link';

type Guide = {
  id: string;
  slug: string;
  name: string;
  avatarUrl?: string | null;
  experienceYears?: number | null;
  rating?: { value: number; count: number } | null;
  bio?: string | null;
};

export default function TourGuideCard({ guide }: { guide: Guide }) {
  return (
    <Link
      href={`/gidy/${guide.slug}`}
      className="flex gap-4 rounded-xl border border-gray-200 p-4 transition hover:border-gray-300 hover:bg-gray-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gray-400"
    >
      {guide.avatarUrl && (
        <Image
          src={guide.avatarUrl}
          alt={`Гид ${guide.name}`}
          width={64}
          height={64}
          className="h-16 w-16 rounded-full object-cover"
        />
      )}
      <div className="min-w-0">
        <div className="font-semibold">{guide.name}</div>
        <div className="mt-0.5 text-sm text-gray-500">
          {guide.experienceYears ? `${guide.experienceYears} лет опыта` : 'Авторский гид'}
          {guide.rating && guide.rating.count > 0 && (
            <> · ★ {guide.rating.value} ({guide.rating.count})</>
          )}
        </div>
        {guide.bio && <p className="mt-2 line-clamp-2 text-sm text-gray-700">{guide.bio}</p>}
        <span className="mt-2 inline-block text-sm font-medium text-emerald-700">
          Все туры гида →
        </span>
      </div>
    </Link>
  );
}
