'use client';
// components/tour/TourBookingBar.tsx
// Липкая нижняя панель с двумя CTA. На мобильных всегда под пальцем — главное для конверсии.
// Активные глаголы в подписях: кнопка говорит ровно то, что произойдёт.

import { useState } from 'react';
import AskQuestionModal from './AskQuestionModal';

type Props = {
  tourId: string;
  tourTitle: string;
  guideId: string | null;
  price: number;
};

export default function TourBookingBar({ tourId, tourTitle, guideId, price }: Props) {
  const [askOpen, setAskOpen] = useState(false);

  function handleBook() {
    // Цель аналитики — чтобы мерить конверсию (см. analytics/metrika.tsx)
    window.ym?.(/* counterId */ 0, 'reachGoal', 'book_click', { tourId });
    // TODO: переход в форму бронирования / открытие модалки брони
    window.location.href = `/booking/${tourId}`;
  }

  return (
    <>
      {/* Липкая панель: fixed снизу на мобильных, в потоке на десктопе можно продублировать в hero */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <div className="mr-auto leading-tight">
            <div className="text-xs text-gray-500">Стоимость</div>
            <div className="text-base font-semibold">
              от {price.toLocaleString('ru-RU')} ₽
            </div>
          </div>

          <button
            type="button"
            onClick={() => setAskOpen(true)}
            className="rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-800 transition hover:bg-gray-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gray-400"
          >
            Задать вопрос
          </button>

          <button
            type="button"
            onClick={handleBook}
            className="rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700"
          >
            Забронировать
          </button>
        </div>
      </div>

      <AskQuestionModal
        open={askOpen}
        onClose={() => setAskOpen(false)}
        tourId={tourId}
        tourTitle={tourTitle}
        guideId={guideId}
      />
    </>
  );
}
