// components/tour/TourFaq.tsx
// Доступный аккордеон на нативных <details>/<summary> — работает без JS,
// что важно: содержимое FAQ должно быть в DOM и при выключенном JS (для FAQPage-разметки).

import type { FaqItem } from '@/lib/seo/jsonld';

export default function TourFaq({ items }: { items: FaqItem[] }) {
  return (
    <div className="mt-4 divide-y divide-gray-200 rounded-lg border border-gray-200">
      {items.map((item, i) => (
        <details key={i} className="group px-4 py-3 [&_summary]:cursor-pointer">
          <summary className="flex list-none items-center justify-between font-medium">
            <span>{item.question}</span>
            <span className="ml-4 text-gray-400 transition group-open:rotate-45">+</span>
          </summary>
          <p className="mt-2 text-gray-700">{item.answer}</p>
        </details>
      ))}
    </div>
  );
}
