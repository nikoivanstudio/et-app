// components/analytics/Metrika.tsx
// Яндекс.Метрика + цели. Без целей нельзя измерить эффект изменений -> ставим сразу.
// Подключить в app/layout.tsx внутри <body>.
import Script from 'next/script';

const COUNTER_ID = process.env.NEXT_PUBLIC_YM_ID; // например '12345678'

export default function Metrika() {
  if (!COUNTER_ID) return null;
  return (
    <>
      <Script id="ym" strategy="afterInteractive">
        {`
          (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
          m[i].l=1*new Date();
          for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
          k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
          (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
          ym(${COUNTER_ID}, "init", {
            clickmap:true, trackLinks:true, accurateTrackBounce:true,
            webvisor:true   // запись сессий — увидите, где люди застревают в бронировании
          });
        `}
      </Script>
      <noscript>
        <div>
          <img
            src={`https://mc.yandex.ru/watch/${COUNTER_ID}`}
            style={{ position: 'absolute', left: '-9999px' }}
            alt=""
          />
        </div>
      </noscript>
    </>
  );
}

// Типизация window.ym, чтобы вызывать reachGoal из любых компонентов:
declare global {
  interface Window {
    ym?: (counterId: number, action: string, ...args: unknown[]) => void;
  }
}

// Хелпер (необязательный): берёт ID из env, чтобы не хардкодить.
export function reachGoal(goal: string, params?: Record<string, unknown>) {
  const id = Number(process.env.NEXT_PUBLIC_YM_ID);
  if (id && typeof window !== 'undefined') window.ym?.(id, 'reachGoal', goal, params);
}

// Рекомендованные цели (создать в интерфейсе Метрики как «JavaScript-событие»):
//   book_click      — нажал «Забронировать»
//   ask_question    — отправил вопрос гиду
//   booking_started — открыл форму брони
//   booking_paid    — оплатил  (главная цель)
// В компонентах меняйте window.ym?.(0, ...) на reachGoal('book_click', {...}).
