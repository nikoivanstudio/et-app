// app/sitemap.ts
// Next.js отдаёт это по адресу /sitemap.xml
// Динамически тянет все туры/гидов/категории из БД -> новые туры попадают в карту автоматически.
import type { MetadataRoute } from 'next';
import { query } from '@/lib/db'; // см. messaging/lib-db.ts

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://energy-tur.ru';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // TODO: подставьте реальные имена таблиц/полей.
  const { rows: tours } = await query<{ slug: string; updated_at: Date }>(
    `select slug, updated_at from tours where published = true`
  );
  const { rows: guides } = await query<{ slug: string; updated_at: Date }>(
    `select slug, updated_at from users where role = 'guide' and active = true`
  );
  const { rows: categories } = await query<{ slug: string; updated_at: Date }>(
    `select slug, updated_at from categories`
  );

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${BASE_URL}/`, changeFrequency: 'daily', priority: 1 },
    { url: `${BASE_URL}/tury`, changeFrequency: 'daily', priority: 0.9 },
    { url: `${BASE_URL}/gidy`, changeFrequency: 'weekly', priority: 0.6 },
  ];

  const tourPages: MetadataRoute.Sitemap = tours.map((t) => ({
    url: `${BASE_URL}/tury/${t.slug}`,
    lastModified: t.updated_at,
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  const guidePages: MetadataRoute.Sitemap = guides.map((g) => ({
    url: `${BASE_URL}/gidy/${g.slug}`,
    lastModified: g.updated_at,
    changeFrequency: 'monthly',
    priority: 0.5,
  }));

  const categoryPages: MetadataRoute.Sitemap = categories.map((c) => ({
    url: `${BASE_URL}/tury/${c.slug}`,
    lastModified: c.updated_at,
    changeFrequency: 'weekly',
    priority: 0.7,
  }));

  return [...staticPages, ...tourPages, ...categoryPages, ...guidePages];
}

// Подсказка: после деплоя отправьте sitemap в Яндекс.Вебмастер и Google Search Console.
// Для мгновенной индексации новых туров используйте IndexNow (Яндекс поддерживает):
// при публикации тура шлите POST на https://yandex.com/indexnow с url тура.
