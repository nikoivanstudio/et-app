// lib/seo/jsonld.ts
// Билдеры микроразметки Schema.org (JSON-LD).
// Они дают расширенные сниппеты в выдаче: цена, звёзды рейтинга, хлебные крошки, FAQ.

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://energy-tur.ru';

// Доменные типы — подставьте свои.
export type TourForSeo = {
  slug: string;
  title: string;
  description: string;
  images: string[]; // абсолютные URL (Minio)
  price: number;
  currency?: string; // 'RUB'
  durationDays?: number;
  rating?: { value: number; count: number } | null;
  guide?: { name: string; slug: string } | null;
  region?: string | null;
};

export type FaqItem = { question: string; answer: string };

/**
 * Product + Offer — главный тип для сниппета с ценой и наличием.
 * AggregateRating добавляем только при наличии реальных отзывов (иначе Google ругается).
 */
export function tourProductJsonLd(tour: TourForSeo) {
  const url = `${BASE_URL}/tury/${tour.slug}`;
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: tour.title,
    description: tour.description,
    image: tour.images,
    url,
    brand: { '@type': 'Brand', name: 'energy-tur' },
    offers: {
      '@type': 'Offer',
      price: tour.price,
      priceCurrency: tour.currency ?? 'RUB',
      availability: 'https://schema.org/InStock',
      url,
    },
  };

  if (tour.rating && tour.rating.count > 0) {
    data.aggregateRating = {
      '@type': 'AggregateRating',
      ratingValue: tour.rating.value,
      reviewCount: tour.rating.count,
    };
  }

  return data;
}

/**
 * TouristTrip — семантический тип именно для тура (маршрут, длительность).
 * Поддерживает понимание Яндексом/Google, что это турпродукт.
 */
export function touristTripJsonLd(tour: TourForSeo) {
  return {
    '@context': 'https://schema.org',
    '@type': 'TouristTrip',
    name: tour.title,
    description: tour.description,
    url: `${BASE_URL}/tury/${tour.slug}`,
    ...(tour.region ? { touristType: tour.region } : {}),
    ...(tour.guide
      ? { provider: { '@type': 'Person', name: tour.guide.name } }
      : {}),
    offers: {
      '@type': 'Offer',
      price: tour.price,
      priceCurrency: tour.currency ?? 'RUB',
    },
  };
}

/**
 * FAQPage — блок «Вопросы и ответы» может вылезти прямо в выдаче.
 */
export function faqJsonLd(items: FaqItem[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((i) => ({
      '@type': 'Question',
      name: i.question,
      acceptedAnswer: { '@type': 'Answer', text: i.answer },
    })),
  };
}

/**
 * Хлебные крошки в сниппете.
 */
export function breadcrumbJsonLd(trail: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((c, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: c.name,
      item: `${BASE_URL}${c.path}`,
    })),
  };
}

/**
 * Организация — на уровне всего сайта (в layout.tsx).
 */
export function organizationJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'TravelAgency',
    name: 'energy-tur',
    url: BASE_URL,
    // TODO: заполните реальные данные — это коммерческие факторы Яндекса.
    // logo: `${BASE_URL}/logo.png`,
    // telephone: '+7...',
    // sameAs: ['https://t.me/...', 'https://vk.com/...'],
  };
}

/** Хелпер для безопасной вставки в <script>. */
export function jsonLdScript(data: object) {
  return { __html: JSON.stringify(data) };
}
